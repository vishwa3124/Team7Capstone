<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Login | Online Food Ordering</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="style.css" />
</head>

<body class="auth-page">

  <div class="auth-card">

    <!-- LEFT SIDE -->
    <div class="auth-media">
      <div class="auth-brand">
        <img src="images/logo.png" alt="App Logo" class="auth-logo" />
        <h1>Welcome Back</h1>
        <p>Login to manage your orders, cart, and checkout faster.</p>
      </div>

      <img
        src="images/login-illustration.png"
        alt="Login illustration"
        class="auth-illustration"
      />
    </div>

    <!-- RIGHT SIDE -->
    <div class="auth-form">
      <h2>User Login</h2>
      <p class="auth-subtitle">Enter your login details</p>

      <?php require_once __DIR__ . "/backend/flash_snippet.php"; ?>
      <form action="login.php" method="POST">
        <div class="input-group">
          <label>Email Address</label>
          <input type="email" name="email" required />
        </div>

        <div class="input-group">
          <label>Password</label>
          <input type="password" name="password" required />
        </div>

        <button type="submit" class="btn-auth">Login</button>

        <p class="auth-alt">
          Don’t have an account?
          <a href="register_view.php">Register here</a>
        </p>
      </form>
    </div>

  </div>

</body>
</html>
