<?php
// logout.php
declare(strict_types=1);

require_once __DIR__ . '/backend/auth.php';

auth_logout();
flash_set('success', 'Logged out.');
redirect('login_view.php');
