<?php
declare(strict_types=1);
require_once __DIR__ . '/backend/auth.php';
require_login('login_view.php');
$user = auth_user();
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>My Profile</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <div class="nav">
    <a class="brand" href="index.php">Online Food Ordering</a>
    <div class="links">
      <a href="restaurants.html">Restaurants</a>
      <a href="menu.html">Menu</a>
      <a href="profile.php" class="active">Profile</a>
      <a href="logout.php">Logout</a>
    </div>
  </div>

  <div class="container" style="max-width:900px;margin:30px auto;padding:0 15px;">
    <h1 style="margin-bottom:10px;">My Profile</h1>
    <p><strong>Name:</strong> <?= h($user['fullname'] ?? '') ?></p>
    <p><strong>Email:</strong> <?= h($user['email'] ?? '') ?></p>
    <p><strong>Member since:</strong> <?= h($user['created_at'] ?? '') ?></p>
  </div>
</body>
</html>
