<?php
// backend/flash_snippet.php
declare(strict_types=1);
require_once __DIR__ . '/helpers.php';

$err = flash_get('error');
$ok  = flash_get('success');
if ($err): ?>
  <div style="margin: 0 0 12px; padding: 10px; border-radius: 10px; background:#ffe9e9; color:#7a0000;">
    <?= h($err) ?>
  </div>
<?php endif; ?>
<?php if ($ok): ?>
  <div style="margin: 0 0 12px; padding: 10px; border-radius: 10px; background:#e9ffef; color:#0c5b2a;">
    <?= h($ok) ?>
  </div>
<?php endif; ?>
