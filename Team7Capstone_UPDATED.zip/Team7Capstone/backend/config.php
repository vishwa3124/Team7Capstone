<?php
// backend/config.php
// Update these settings for your MySQL server (XAMPP/WAMP/MAMP/LocalDB-like MySQL)
declare(strict_types=1);

const DB_HOST = '127.0.0.1';
const DB_NAME = 'foodapp';
const DB_USER = 'root';
const DB_PASS = ''; // XAMPP default is empty

const APP_BASE_URL = ''; // e.g. 'http://localhost/Team7Capstone-VishwaRana-Feature-UserAuthentication' (optional)

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    return $pdo;
}
