<?php
// backend/helpers.php
declare(strict_types=1);

function start_session(): void {
    if (session_status() === PHP_SESSION_NONE) {
        // Secure defaults (works in localhost too)
        ini_set('session.use_strict_mode', '1');
        session_start();
    }
}

function redirect(string $path): never {
    header('Location: ' . $path);
    exit;
}

function is_post(): bool {
    return ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
}

function input(string $key, string $default=''): string {
    return trim((string)($_POST[$key] ?? $default));
}

function flash_set(string $key, string $message): void {
    start_session();
    $_SESSION['flash'][$key] = $message;
}

function flash_get(string $key): ?string {
    start_session();
    $msg = $_SESSION['flash'][$key] ?? null;
    if ($msg !== null) unset($_SESSION['flash'][$key]);
    return $msg;
}

function h(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
