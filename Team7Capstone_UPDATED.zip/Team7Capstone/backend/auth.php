<?php
// backend/auth.php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/helpers.php';

function auth_login(int $user_id): void {
    start_session();
    session_regenerate_id(true);
    $_SESSION['user_id'] = $user_id;
}

function auth_logout(): void {
    start_session();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params['path'], $params['domain'],
            (bool)$params['secure'], (bool)$params['httponly']
        );
    }
    session_destroy();
}

function auth_user(): ?array {
    start_session();
    $uid = $_SESSION['user_id'] ?? null;
    if (!$uid) return null;

    $stmt = db()->prepare('SELECT id, fullname, email, created_at FROM users WHERE id = ?');
    $stmt->execute([(int)$uid]);
    $user = $stmt->fetch();
    return $user ?: null;
}

function require_login(string $redirect_to='login_view.php'): void {
    if (!auth_user()) {
        flash_set('error', 'Please log in first.');
        redirect($redirect_to);
    }
}
